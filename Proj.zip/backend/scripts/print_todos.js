import fs from 'fs';
const p = new URL('../todo_progress.json', import.meta.url).pathname;
try {
  const txt = fs.readFileSync(p, 'utf8');
  console.log('=== TODO PROGRESS ===');
  console.log(txt);
} catch (e) {
  console.error('Failed to read todo_progress.json:', e.message);
}
