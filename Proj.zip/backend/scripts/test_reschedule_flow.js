const API = 'http://localhost:5000';

async function reqJson(url, opts = {}) {
  const r = await fetch(url, Object.assign({ headers: { 'Content-Type': 'application/json' }, credentials: 'include' }, opts));
  const text = await r.text();
  try { return r.ok ? JSON.parse(text) : { status: r.status, error: JSON.parse(text) } } catch { return r.ok ? text : { status: r.status, error: text }; }
}

async function run() {
  try {
    // 1. register student A
    const student = { username: 'student1', email: 'student1@example.com', password: 'password123', studentId: '1234567890', fullName: 'Student One' };
    const sres = await reqJson(`${API}/api/auth/register`, { method: 'POST', body: JSON.stringify(student) });
    console.log('register student:', sres && sres.token ? 'ok' : sres);

    // 2. register student B (advisor)
    const adv = { username: 'advisor1', email: 'advisor1@example.com', password: 'password123', studentId: '0987654321', fullName: 'Advisor One' };
    const ares = await reqJson(`${API}/api/auth/register`, { method: 'POST', body: JSON.stringify(adv) });
    console.log('register advisor (as student role):', ares && ares.token ? 'ok' : ares);

    const tokenA = sres.token || '';
    const tokenB = ares.token || '';

    if (!tokenA || !tokenB) {
      console.log('Tokens not available, aborting');
      return;
    }

    // 3. create a project where advisor is user B and member is user A.
    const projectPayload = { name: 'Test Project', advisor: ares.user.id, members: [sres.user.id], description: 'Auto project' };
    const pres = await reqJson(`${API}/api/projects`, { method: 'POST', body: JSON.stringify(projectPayload), headers: { Authorization: `Bearer ${tokenB}` } });
    console.log('create project:', pres);

    const projectId = pres && (pres._id || pres.id || (pres.project && pres.project._id));
    if (!projectId) {
      console.log('Project creation failed, aborting');
      return;
    }

    // 4. Create an appointment by advisor (user B)
    const apptPayload = { title: 'Meeting', description: 'Discuss', date: '2025-10-20', startTime: '10:00', endTime: '11:00', meetingType: 'online', project: projectId };
    const apptRes = await reqJson(`${API}/api/appointments`, { method: 'POST', body: JSON.stringify(apptPayload), headers: { Authorization: `Bearer ${tokenB}` } });
    console.log('create appointment:', apptRes && apptRes._id ? 'ok' : apptRes);
    const apptId = apptRes._id || apptRes.id;
    if (!apptId) return;

    // 5. Advisor requests reschedule
    const reqRes = await reqJson(`${API}/api/appointments/${apptId}/reschedule-request`, { method: 'POST', body: JSON.stringify({ date: '2025-10-21', startTime: '11:00', endTime: '12:00', reason: 'Conflict' }), headers: { Authorization: `Bearer ${tokenB}` } });
    console.log('request reschedule:', reqRes && reqRes._id ? 'ok' : reqRes);

    // 6. Student A responds to reschedule (accept)
    const resp = await reqJson(`${API}/api/appointments/${apptId}/reschedule-response`, { method: 'POST', body: JSON.stringify({ accepted: true }), headers: { Authorization: `Bearer ${tokenA}` } });
    console.log('respond reschedule (accept):', resp && resp._id ? 'ok' : resp);

    // 7. fetch appointment
    const final = await reqJson(`${API}/api/appointments/${apptId}`, { method: 'GET', headers: { Authorization: `Bearer ${tokenA}` } });
    console.log('final appointment:', final && final._id ? final.status : final);
  } catch (e) {
    console.error('Script error', e && e.message ? e.message : e);
  }
}

run();
