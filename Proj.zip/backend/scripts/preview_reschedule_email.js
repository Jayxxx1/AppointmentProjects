import { renderRescheduleRequestEmail } from '../utils/emailTemplates.js';
import Appointment from '../models/Appointment.js';

(async () => {
  try {
    const fake = { _id: '000000000000000000000000', title: 'Test', project: { name: 'Proj' }, date: '2025-10-20', startTime: '10:00', endTime: '11:00' };
    const html = renderRescheduleRequestEmail({ appointment: fake, rescheduleDetails: { date: '2025-10-21', startTime: '11:00', endTime: '12:00', reason: 'Conflict' } });
    console.log('OK - generated length', html.length);
  } catch (e) {
    console.error('ERR', e.message);
  }
})();
