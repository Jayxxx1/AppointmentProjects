Just wait for Sucessfully 100% bro i can got it 
